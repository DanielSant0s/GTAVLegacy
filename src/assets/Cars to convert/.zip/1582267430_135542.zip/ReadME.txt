Hakumai SA style ImVehFt
by HamX Mod Garage 2020
part of GTA World of Agniesia 3.0

LINES:

vehicles.ide:
477, 	zr350, 		zr350, 		car, 		WINDSOR,		ZR350, 		null,	richfamily, 	10, 	0,	0,		-1, 0.76, 0.76,		0

carcols.dat:
zr350, 1,0