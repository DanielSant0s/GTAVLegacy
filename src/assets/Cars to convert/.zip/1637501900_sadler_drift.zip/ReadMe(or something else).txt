Credits:
Sadler Model: L3AS
Others: Rockstar Games

Installation:
put the DFF to gta3.img using any DFF Editor, and put the Texture to any TXD Editor remember use "With Alpha"

Handling:
1260.0    2210.0 	2.0    0.0 0.1 -0.900 75 0.49 0.75 0.57 	5 260.0 30.0 1.0  4 P 	15.5  0.5  0 50.0 	1.2  0.20  0.01  0.300 -0.1 0.5  0.3 	    1.10 0.60 135000 	2004 	80000E 	1 	1 	0

Enjoy your new Whip to Drift!!